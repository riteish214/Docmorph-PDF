# Checkers Royal

Checkers Royal is a real-time multiplayer checkers game built with React and Supabase.
Players can create or join game rooms, play live matches, and communicate through in-game chat.
The project uses Supabase Realtime for instant synchronization of moves, messages, and game state across players.

---

## 🧱 Tech Stack

* **Frontend:** React, Vite
* **Backend:** Supabase (PostgreSQL, Realtime)
* **Styling:** Tailwind CSS
* **Language:** JavaScript / TypeScript

---

## ✨ Features

* Real-time multiplayer gameplay
* Room creation and joining system
* In-game chat support
* Move history tracking
* Realtime synchronization using Supabase

---

