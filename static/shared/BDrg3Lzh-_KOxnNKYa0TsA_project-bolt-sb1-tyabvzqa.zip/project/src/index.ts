import app from './app';
import { config } from './config/env';
import { initializeElasticsearch } from './config/elasticsearch';
import { imapService } from './services/imapService';
import { emailStoreService } from './services/emailStoreService';
import { aiCategorizerService } from './services/aiCategorizerService';
import { notificationService } from './services/notificationService';
import { accountService } from './services/accountService';
import logger from './utils/logger';

async function startServer() {
  try {
    logger.info('Starting Onebox Email Backend...');

    await initializeElasticsearch();
    logger.info('Elasticsearch initialized');

    imapService.on('newEmail', async (email) => {
      try {
        logger.info(`Processing new email: ${email.subject}`);

        const category = await aiCategorizerService.categorizeEmail(email);

        await emailStoreService.indexEmail(email, category);

        await notificationService.sendNotifications(email, category);

        logger.info(`Email processed successfully: ${email.subject} [${category}]`);
      } catch (error) {
        logger.error('Error processing new email:', error);
      }
    });

    const envAccounts = config.imap.accounts;
    if (envAccounts.length > 0) {
      logger.info(`Connecting ${envAccounts.length} IMAP accounts from environment...`);
      for (const account of envAccounts) {
        imapService.connectAccount(account).catch((error) => {
          logger.error(`Failed to connect ${account.email}:`, error);
        });
      }
    }

    if (config.supabase.url && config.supabase.anonKey) {
      try {
        const dbAccounts = await accountService.getAccounts();
        logger.info(`Found ${dbAccounts.length} accounts in database`);

        for (const storedAccount of dbAccounts) {
          const accountWithPassword = await accountService.getAccountWithPassword(storedAccount.email);
          if (accountWithPassword) {
            imapService.connectAccount(accountWithPassword).catch((error) => {
              logger.error(`Failed to connect ${storedAccount.email}:`, error);
            });
          }
        }
      } catch (error) {
        logger.warn('Could not load accounts from database:', error);
      }
    }

    const server = app.listen(config.server.port, () => {
      logger.info(`Server running on port ${config.server.port}`);
      logger.info('API Endpoints:');
      logger.info(`  GET  /health`);
      logger.info(`  GET  /accounts`);
      logger.info(`  POST /accounts`);
      logger.info(`  GET  /emails?account=&folder=&q=`);
      logger.info(`  GET  /emails/:id`);
    });

    const gracefulShutdown = async () => {
      logger.info('Shutting down gracefully...');

      server.close(() => {
        logger.info('HTTP server closed');
      });

      await imapService.disconnectAll();
      logger.info('IMAP connections closed');

      process.exit(0);
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
