import OpenAI from 'openai';
import { config } from '../config/env';
import { ParsedEmail } from './imapService';
import logger from '../utils/logger';

export type EmailCategory = 'Interested' | 'Meeting Booked' | 'Not Interested' | 'Spam' | 'Out of Office';

export class AICategorizerService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({
      apiKey: config.openai.apiKey,
    });
  }

  async categorizeEmail(email: ParsedEmail): Promise<EmailCategory> {
    try {
      const prompt = this.buildCategorizationPrompt(email);

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `You are an email categorization assistant. Categorize emails into exactly one of these categories: "Interested", "Meeting Booked", "Not Interested", "Spam", "Out of Office".

            Guidelines:
            - "Interested": Emails showing interest in a product, service, or collaboration
            - "Meeting Booked": Emails confirming meetings, calendar invites, or scheduling confirmations
            - "Not Interested": Polite rejections or explicit disinterest
            - "Spam": Unsolicited promotional emails, phishing attempts, or irrelevant content
            - "Out of Office": Automatic replies indicating the person is away

            Respond with ONLY the category name, nothing else.`,
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.3,
        max_tokens: 20,
      });

      const category = completion.choices[0]?.message?.content?.trim() as EmailCategory;

      if (this.isValidCategory(category)) {
        logger.info(`Categorized email "${email.subject}" as: ${category}`);
        return category;
      }

      logger.warn(`Invalid category received: ${category}. Defaulting to "Not Interested"`);
      return 'Not Interested';
    } catch (error) {
      logger.error('Error categorizing email with OpenAI:', error);
      return 'Not Interested';
    }
  }

  private buildCategorizationPrompt(email: ParsedEmail): string {
    return `
Email Details:
From: ${email.from}
Subject: ${email.subject}
Body Preview: ${email.body.substring(0, 500)}

Categorize this email.
    `.trim();
  }

  private isValidCategory(category: string): category is EmailCategory {
    const validCategories: EmailCategory[] = [
      'Interested',
      'Meeting Booked',
      'Not Interested',
      'Spam',
      'Out of Office',
    ];
    return validCategories.includes(category as EmailCategory);
  }
}

export const aiCategorizerService = new AICategorizerService();
