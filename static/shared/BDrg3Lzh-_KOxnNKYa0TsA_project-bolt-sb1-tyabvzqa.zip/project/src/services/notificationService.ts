import { config } from '../config/env';
import { ParsedEmail } from './imapService';
import { EmailCategory } from './aiCategorizerService';
import logger from '../utils/logger';

export class NotificationService {
  async sendNotifications(email: ParsedEmail, category: EmailCategory): Promise<void> {
    if (category === 'Interested') {
      await Promise.all([
        this.sendSlackNotification(email, category),
        this.sendCustomWebhook(email, category),
      ]);
    }
  }

  private async sendSlackNotification(email: ParsedEmail, category: EmailCategory): Promise<void> {
    const slackUrl = config.notifications.slackWebhookUrl;

    if (!slackUrl) {
      logger.warn('Slack webhook URL not configured');
      return;
    }

    try {
      const payload = {
        text: `New Interested Email Received`,
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: 'New Interested Email',
            },
          },
          {
            type: 'section',
            fields: [
              {
                type: 'mrkdwn',
                text: `*From:*\n${email.from}`,
              },
              {
                type: 'mrkdwn',
                text: `*Account:*\n${email.accountEmail}`,
              },
              {
                type: 'mrkdwn',
                text: `*Subject:*\n${email.subject}`,
              },
              {
                type: 'mrkdwn',
                text: `*Category:*\n${category}`,
              },
            ],
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Preview:*\n${email.body.substring(0, 200)}...`,
            },
          },
        ],
      };

      const response = await fetch(slackUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Slack API error: ${response.status}`);
      }

      logger.info(`Slack notification sent for email: ${email.subject}`);
    } catch (error) {
      logger.error('Failed to send Slack notification:', error);
    }
  }

  private async sendCustomWebhook(email: ParsedEmail, category: EmailCategory): Promise<void> {
    const webhookUrl = config.notifications.customWebhookUrl;

    if (!webhookUrl) {
      logger.warn('Custom webhook URL not configured');
      return;
    }

    try {
      const payload = {
        event: 'email.interested',
        timestamp: new Date().toISOString(),
        data: {
          id: email.id,
          accountEmail: email.accountEmail,
          from: email.from,
          to: email.to,
          subject: email.subject,
          date: email.date,
          folder: email.folder,
          category,
          bodyPreview: email.body.substring(0, 500),
        },
      };

      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Webhook error: ${response.status}`);
      }

      logger.info(`Custom webhook sent for email: ${email.subject}`);
    } catch (error) {
      logger.error('Failed to send custom webhook:', error);
    }
  }
}

export const notificationService = new NotificationService();
