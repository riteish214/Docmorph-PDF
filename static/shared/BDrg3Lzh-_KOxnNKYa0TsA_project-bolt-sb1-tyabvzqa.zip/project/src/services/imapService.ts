import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import { EventEmitter } from 'events';
import { IMAPAccount } from '../config/env';
import { createIMAPConfig } from '../config/imap';
import logger from '../utils/logger';

export interface ParsedEmail {
  id: string;
  accountEmail: string;
  subject: string;
  from: string;
  to: string[];
  date: Date;
  folder: string;
  body: string;
}

export class IMAPService extends EventEmitter {
  private connections: Map<string, ImapFlow> = new Map();
  private reconnectTimers: Map<string, NodeJS.Timeout> = new Map();

  async connectAccount(account: IMAPAccount): Promise<void> {
    const config = createIMAPConfig(account);

    try {
      const client = new ImapFlow(config);

      client.on('error', (err) => {
        logger.error(`IMAP error for ${account.email}:`, err);
        this.scheduleReconnect(account);
      });

      client.on('close', () => {
        logger.warn(`IMAP connection closed for ${account.email}`);
        this.scheduleReconnect(account);
      });

      await client.connect();
      logger.info(`Connected to IMAP for ${account.email}`);

      this.connections.set(account.email, client);

      await this.fetchRecentEmails(account.email, client);
      await this.startIdleMode(account.email, client);
    } catch (error) {
      logger.error(`Failed to connect IMAP for ${account.email}:`, error);
      this.scheduleReconnect(account);
    }
  }

  private async fetchRecentEmails(accountEmail: string, client: ImapFlow): Promise<void> {
    try {
      const mailboxes = await this.listMailboxes(client);

      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      for (const mailbox of mailboxes) {
        try {
          await client.mailboxOpen(mailbox);

          const messages = client.fetch(
            { since: thirtyDaysAgo },
            {
              uid: true,
              envelope: true,
              bodyStructure: true,
              source: true
            }
          );

          for await (const message of messages) {
            try {
              const parsed = await this.parseMessage(message, accountEmail, mailbox);
              if (parsed) {
                this.emit('newEmail', parsed);
              }
            } catch (error) {
              logger.error(`Error parsing message in ${mailbox}:`, error);
            }
          }

          logger.info(`Fetched emails from ${mailbox} for ${accountEmail}`);
        } catch (error) {
          logger.error(`Error fetching from mailbox ${mailbox}:`, error);
        }
      }
    } catch (error) {
      logger.error(`Error fetching recent emails for ${accountEmail}:`, error);
    }
  }

  private async listMailboxes(client: ImapFlow): Promise<string[]> {
    const mailboxes: string[] = [];

    try {
      const list = await client.list();

      for (const mailbox of list) {
        mailboxes.push(mailbox.path);
      }
    } catch (error) {
      logger.error('Error listing mailboxes:', error);
      return ['INBOX'];
    }

    return mailboxes.length > 0 ? mailboxes : ['INBOX'];
  }

  private async startIdleMode(accountEmail: string, client: ImapFlow): Promise<void> {
    try {
      await client.mailboxOpen('INBOX');

      client.on('exists', async (data) => {
        logger.info(`New email exists event for ${accountEmail}:`, data);

        try {
          const message = await client.fetchOne(data.path, {
            uid: true,
            envelope: true,
            bodyStructure: true,
            source: true,
          });

          const parsed = await this.parseMessage(message, accountEmail, 'INBOX');
          if (parsed) {
            this.emit('newEmail', parsed);
          }
        } catch (error) {
          logger.error(`Error fetching new message for ${accountEmail}:`, error);
        }
      });

      const idleLoop = async () => {
        while (this.connections.has(accountEmail)) {
          try {
            await client.idle();
          } catch (error) {
            logger.error(`IDLE error for ${accountEmail}:`, error);
            break;
          }
        }
      };

      idleLoop();
      logger.info(`Started IDLE mode for ${accountEmail}`);
    } catch (error) {
      logger.error(`Failed to start IDLE mode for ${accountEmail}:`, error);
    }
  }

  private async parseMessage(message: any, accountEmail: string, folder: string): Promise<ParsedEmail | null> {
    try {
      const source = message.source instanceof Buffer ? message.source : Buffer.from(message.source);
      const parsed = await simpleParser(source);

      const fromValue = Array.isArray(parsed.from) ? parsed.from[0] : parsed.from;
      const from = fromValue?.value?.[0]?.address || fromValue?.text || '';

      const toValue = parsed.to ? (Array.isArray(parsed.to) ? parsed.to : [parsed.to]) : [];
      const to = toValue.flatMap((t: any) => t?.value?.map((v: any) => v.address) || [t?.text] || []).filter(Boolean);
      const subject = parsed.subject || '(No Subject)';
      const body = parsed.text || parsed.html || '';
      const date = parsed.date || new Date();
      const messageId = parsed.messageId || `${accountEmail}-${message.uid}-${Date.now()}`;

      return {
        id: messageId,
        accountEmail,
        subject,
        from,
        to,
        date,
        folder,
        body,
      };
    } catch (error) {
      logger.error('Error parsing message:', error);
      return null;
    }
  }

  private scheduleReconnect(account: IMAPAccount): void {
    const existingTimer = this.reconnectTimers.get(account.email);
    if (existingTimer) {
      clearTimeout(existingTimer);
    }

    const timer = setTimeout(() => {
      logger.info(`Attempting to reconnect ${account.email}...`);
      this.connectAccount(account);
    }, 30000);

    this.reconnectTimers.set(account.email, timer);
  }

  async disconnectAccount(accountEmail: string): Promise<void> {
    const client = this.connections.get(accountEmail);
    if (client) {
      try {
        await client.logout();
        this.connections.delete(accountEmail);
        logger.info(`Disconnected IMAP for ${accountEmail}`);
      } catch (error) {
        logger.error(`Error disconnecting ${accountEmail}:`, error);
      }
    }

    const timer = this.reconnectTimers.get(accountEmail);
    if (timer) {
      clearTimeout(timer);
      this.reconnectTimers.delete(accountEmail);
    }
  }

  async disconnectAll(): Promise<void> {
    const emails = Array.from(this.connections.keys());
    await Promise.all(emails.map((email) => this.disconnectAccount(email)));
  }
}

export const imapService = new IMAPService();
