import { createClient } from '@supabase/supabase-js';
import { config, IMAPAccount } from '../config/env';
import logger from '../utils/logger';

const supabase = createClient(config.supabase.url, config.supabase.anonKey);

export interface StoredAccount {
  id: string;
  email: string;
  host: string;
  port: number;
  created_at: string;
}

export class AccountService {
  async addAccount(account: IMAPAccount): Promise<StoredAccount> {
    try {
      const { data, error } = await supabase
        .from('imap_accounts')
        .insert({
          email: account.email,
          password: account.password,
          host: account.host,
          port: account.port,
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      logger.info(`Account added: ${account.email}`);
      return data;
    } catch (error) {
      logger.error('Failed to add account:', error);
      throw error;
    }
  }

  async getAccounts(): Promise<StoredAccount[]> {
    try {
      const { data, error } = await supabase
        .from('imap_accounts')
        .select('id, email, host, port, created_at')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      logger.error('Failed to get accounts:', error);
      throw error;
    }
  }

  async getAccountWithPassword(email: string): Promise<IMAPAccount | null> {
    try {
      const { data, error } = await supabase
        .from('imap_accounts')
        .select('email, password, host, port')
        .eq('email', email)
        .maybeSingle();

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      logger.error('Failed to get account with password:', error);
      throw error;
    }
  }

  async deleteAccount(email: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('imap_accounts')
        .delete()
        .eq('email', email);

      if (error) {
        throw error;
      }

      logger.info(`Account deleted: ${email}`);
    } catch (error) {
      logger.error('Failed to delete account:', error);
      throw error;
    }
  }
}

export const accountService = new AccountService();
