import { esClient, EmailDocument, EMAIL_INDEX } from '../config/elasticsearch';
import { ParsedEmail } from './imapService';
import logger from '../utils/logger';

export class EmailStoreService {
  async indexEmail(email: ParsedEmail, category?: string): Promise<void> {
    try {
      const document: EmailDocument = {
        ...email,
        category,
      };

      await esClient.index({
        index: EMAIL_INDEX,
        id: email.id,
        document,
      });

      logger.info(`Indexed email: ${email.subject} from ${email.accountEmail}`);
    } catch (error) {
      logger.error(`Failed to index email ${email.id}:`, error);
      throw error;
    }
  }

  async getEmailById(id: string): Promise<EmailDocument | null> {
    try {
      const result = await esClient.get({
        index: EMAIL_INDEX,
        id,
      });

      return result._source as EmailDocument;
    } catch (error) {
      if ((error as any).meta?.statusCode === 404) {
        return null;
      }
      logger.error(`Failed to get email ${id}:`, error);
      throw error;
    }
  }

  async searchEmails(params: {
    account?: string;
    folder?: string;
    query?: string;
    from?: number;
    size?: number;
  }): Promise<{ emails: EmailDocument[]; total: number }> {
    try {
      const must: any[] = [];

      if (params.account) {
        must.push({ term: { accountEmail: params.account } });
      }

      if (params.folder) {
        must.push({ term: { folder: params.folder } });
      }

      if (params.query) {
        must.push({
          multi_match: {
            query: params.query,
            fields: ['subject', 'body', 'from'],
            type: 'best_fields',
            operator: 'or',
          },
        });
      }

      const body: any = {
        query: must.length > 0 ? { bool: { must } } : { match_all: {} },
        sort: [{ date: { order: 'desc' } }],
        from: params.from || 0,
        size: params.size || 20,
      };

      const result = await esClient.search({
        index: EMAIL_INDEX,
        body,
      });

      const emails = result.hits.hits.map((hit) => hit._source as EmailDocument);
      const total = typeof result.hits.total === 'object' ? result.hits.total.value : (result.hits.total || 0);

      return { emails, total: total || 0 };
    } catch (error) {
      logger.error('Failed to search emails:', error);
      throw error;
    }
  }

  async updateEmailCategory(id: string, category: string): Promise<void> {
    try {
      await esClient.update({
        index: EMAIL_INDEX,
        id,
        doc: { category },
      });

      logger.info(`Updated category for email ${id} to ${category}`);
    } catch (error) {
      logger.error(`Failed to update email category ${id}:`, error);
      throw error;
    }
  }
}

export const emailStoreService = new EmailStoreService();
