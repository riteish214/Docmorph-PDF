import { Client } from '@elastic/elasticsearch';
import { config } from './env';
import logger from '../utils/logger';

export const esClient = new Client({
  node: config.elasticsearch.node,
});

export interface EmailDocument {
  id: string;
  accountEmail: string;
  subject: string;
  from: string;
  to: string[];
  date: Date;
  folder: string;
  body: string;
  category?: string;
}

export const EMAIL_INDEX = 'emails';

export async function initializeElasticsearch(): Promise<void> {
  try {
    const indexExists = await esClient.indices.exists({ index: EMAIL_INDEX });

    if (!indexExists) {
      await esClient.indices.create({
        index: EMAIL_INDEX,
        body: {
          mappings: {
            properties: {
              id: { type: 'keyword' },
              accountEmail: { type: 'keyword' },
              subject: { type: 'text' },
              from: { type: 'text' },
              to: { type: 'keyword' },
              date: { type: 'date' },
              folder: { type: 'keyword' },
              body: { type: 'text' },
              category: { type: 'keyword' },
            },
          },
        },
      });
      logger.info(`Elasticsearch index "${EMAIL_INDEX}" created successfully`);
    } else {
      logger.info(`Elasticsearch index "${EMAIL_INDEX}" already exists`);
    }
  } catch (error) {
    logger.error('Failed to initialize Elasticsearch:', error);
    throw error;
  }
}
