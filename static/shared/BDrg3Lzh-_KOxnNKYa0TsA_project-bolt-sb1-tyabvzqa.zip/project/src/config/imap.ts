import { IMAPAccount } from './env';

export interface IMAPConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
}

export function createIMAPConfig(account: IMAPAccount): IMAPConfig {
  return {
    host: account.host,
    port: account.port,
    secure: true,
    auth: {
      user: account.email,
      pass: account.password,
    },
  };
}
