import dotenv from 'dotenv';

dotenv.config();

export interface IMAPAccount {
  email: string;
  password: string;
  host: string;
  port: number;
}

export const config = {
  elasticsearch: {
    node: process.env.ELASTICSEARCH_NODE || 'http://localhost:9200',
  },
  supabase: {
    url: process.env.SUPABASE_URL || '',
    anonKey: process.env.SUPABASE_ANON_KEY || '',
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY || '',
  },
  notifications: {
    slackWebhookUrl: process.env.SLACK_WEBHOOK_URL || '',
    customWebhookUrl: process.env.CUSTOM_WEBHOOK_URL || '',
  },
  server: {
    port: parseInt(process.env.PORT || '3000', 10),
  },
  imap: {
    accounts: JSON.parse(process.env.IMAP_ACCOUNTS || '[]') as IMAPAccount[],
  },
};
