import { Router, Request, Response } from 'express';
import { accountService } from '../services/accountService';
import { imapService } from '../services/imapService';
import { IMAPAccount } from '../config/env';
import logger from '../utils/logger';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  try {
    const accounts = await accountService.getAccounts();

    res.json({
      success: true,
      data: accounts,
    });
  } catch (error) {
    logger.error('Error fetching accounts:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch accounts',
    });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    const { email, password, host, port } = req.body;

    if (!email || !password || !host || !port) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: email, password, host, port',
      });
    }

    const account: IMAPAccount = {
      email,
      password,
      host,
      port: parseInt(port, 10),
    };

    const stored = await accountService.addAccount(account);

    imapService.connectAccount(account).catch((error) => {
      logger.error(`Failed to connect account ${email}:`, error);
    });

    res.status(201).json({
      success: true,
      data: stored,
      message: 'Account added successfully. IMAP connection initiated.',
    });
  } catch (error) {
    logger.error('Error adding account:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add account',
    });
  }
});

export default router;
