import { Router, Request, Response } from 'express';
import { emailStoreService } from '../services/emailStoreService';
import logger from '../utils/logger';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  try {
    const { account, folder, q, from, size } = req.query;

    const result = await emailStoreService.searchEmails({
      account: account as string,
      folder: folder as string,
      query: q as string,
      from: from ? parseInt(from as string, 10) : 0,
      size: size ? parseInt(size as string, 10) : 20,
    });

    res.json({
      success: true,
      data: result.emails,
      total: result.total,
      from: from ? parseInt(from as string, 10) : 0,
      size: result.emails.length,
    });
  } catch (error) {
    logger.error('Error fetching emails:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch emails',
    });
  }
});

router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const email = await emailStoreService.getEmailById(id);

    if (!email) {
      return res.status(404).json({
        success: false,
        error: 'Email not found',
      });
    }

    res.json({
      success: true,
      data: email,
    });
  } catch (error) {
    logger.error('Error fetching email:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch email',
    });
  }
});

export default router;
