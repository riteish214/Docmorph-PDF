# Onebox Email Aggregator Backend

A feature-rich email aggregator backend with real-time IMAP synchronization, Elasticsearch storage, AI-powered categorization, and notification integrations.

## Features

- **Real-Time IMAP Sync**: Connect multiple email accounts with persistent IDLE connections
- **Elasticsearch Storage**: Full-text search and filtering capabilities
- **AI Categorization**: Automatic email categorization using OpenAI
  - Interested
  - Meeting Booked
  - Not Interested
  - Spam
  - Out of Office
- **Notifications**: Slack and custom webhook integrations for important emails
- **REST API**: Comprehensive endpoints for email and account management

## Prerequisites

- Node.js 18+
- Docker and Docker Compose
- OpenAI API Key
- Supabase Account (for account storage)
- IMAP Email Accounts

## Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Start Elasticsearch

```bash
docker-compose up -d
```

Wait for Elasticsearch to be healthy (check with `docker-compose ps`).

### 3. Configure Environment

Create a `.env` file:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# Elasticsearch
ELASTICSEARCH_NODE=http://localhost:9200

# Supabase
SUPABASE_URL=your_supabase_project_url
SUPABASE_ANON_KEY=your_supabase_anon_key

# OpenAI
OPENAI_API_KEY=your_openai_api_key

# Notifications
SLACK_WEBHOOK_URL=your_slack_webhook_url
CUSTOM_WEBHOOK_URL=your_custom_webhook_url

# Server
PORT=3000

# IMAP Accounts (optional - can also add via API)
IMAP_ACCOUNTS=[{"email":"user@example.com","password":"password","host":"imap.example.com","port":993}]
```

### 4. Set Up Supabase Database

Create the `imap_accounts` table in your Supabase project:

```sql
CREATE TABLE imap_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  host TEXT NOT NULL,
  port INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE imap_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all operations for authenticated users"
  ON imap_accounts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);
```

### 5. Start the Server

```bash
npm run dev
```

## API Endpoints

### Health Check
```
GET /health
```

### Accounts

**Get All Accounts**
```
GET /accounts
```

**Add New Account**
```
POST /accounts
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password",
  "host": "imap.example.com",
  "port": 993
}
```

### Emails

**Search Emails**
```
GET /emails?account=user@example.com&folder=INBOX&q=meeting&from=0&size=20
```

Query Parameters:
- `account` (optional): Filter by account email
- `folder` (optional): Filter by folder name
- `q` (optional): Full-text search query
- `from` (optional): Pagination offset (default: 0)
- `size` (optional): Results per page (default: 20)

**Get Single Email**
```
GET /emails/:id
```

## Architecture

### Services

- **imapService**: Manages IMAP connections, fetches emails, and listens for new messages
- **emailStoreService**: Handles Elasticsearch indexing and search operations
- **aiCategorizerService**: Categorizes emails using OpenAI GPT-3.5
- **notificationService**: Sends Slack and webhook notifications
- **accountService**: Manages IMAP account storage in Supabase

### Email Processing Flow

1. New email detected via IMAP IDLE
2. Email parsed and extracted
3. AI categorization performed
4. Email indexed in Elasticsearch
5. Notifications sent (if categorized as "Interested")

## How It Works

### IMAP Synchronization

- Connects to all configured IMAP accounts
- Fetches last 30 days of emails on startup
- Maintains persistent IDLE connections for real-time updates
- Automatic reconnection on connection loss

### AI Categorization

Uses OpenAI GPT-3.5 Turbo to analyze email content and categorize into:
- **Interested**: Shows interest in products/services
- **Meeting Booked**: Meeting confirmations and calendar invites
- **Not Interested**: Polite rejections
- **Spam**: Unsolicited or irrelevant emails
- **Out of Office**: Automatic away messages

### Notifications

When an email is categorized as "Interested":
- Slack notification with email details
- POST request to custom webhook URL

## Development

### Build for Production

```bash
npm run build
npm start
```

### Project Structure

```
project/
├── src/
│   ├── config/
│   │   ├── elasticsearch.ts   # Elasticsearch client and schema
│   │   ├── imap.ts            # IMAP configuration
│   │   └── env.ts             # Environment configuration
│   ├── services/
│   │   ├── imapService.ts           # IMAP sync and monitoring
│   │   ├── emailStoreService.ts     # Elasticsearch operations
│   │   ├── aiCategorizerService.ts  # OpenAI categorization
│   │   ├── notificationService.ts   # Slack and webhooks
│   │   └── accountService.ts        # Account management
│   ├── routes/
│   │   ├── emails.ts    # Email endpoints
│   │   └── accounts.ts  # Account endpoints
│   ├── utils/
│   │   └── logger.ts    # Winston logger
│   ├── app.ts           # Express app setup
│   └── index.ts         # Entry point
├── docker-compose.yml
├── package.json
└── tsconfig.json
```

## Troubleshooting

### Elasticsearch Connection Issues
```bash
# Check Elasticsearch health
curl http://localhost:9200/_cluster/health

# View Elasticsearch logs
docker-compose logs elasticsearch
```

### IMAP Connection Problems
- Verify credentials and host/port settings
- Check if IMAP is enabled on your email account
- Some providers require app-specific passwords

### OpenAI API Issues
- Verify API key is valid
- Check API quota and rate limits

## License

MIT
